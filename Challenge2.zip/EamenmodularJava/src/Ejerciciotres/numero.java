/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejerciciotres;

/**
 *
 * @author Jeniffer
 */
public class numero {
    int numero1;

    public int getNumero1() {
        return numero1;
    }

    public void setNumero1(int numero1) {
        this.numero1 = numero1;
    }

    public numero(int numero1) {
        this.numero1 = numero1;
    }
}
